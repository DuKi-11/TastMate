const STORAGE_KEY = "taskmate_tasks_v1";
const form = document.getElementById("taskForm");
const titleInput = document.getElementById("taskTitle");
const categoryInput = document.getElementById("taskCategory");
const dueInput = document.getElementById("taskDue");
const memoInput = document.getElementById("taskMemo");
const taskList = document.getElementById("taskList");
const emptyState = document.getElementById("emptyState");
const filterButtons = [...document.querySelectorAll(".filter")];
const sortSelect = document.getElementById("sortSelect");
const submitBtn = document.getElementById("submitBtn");
const cancelEdit = document.getElementById("cancelEdit");
let tasks = loadTasks();
let activeFilter = "すべて";
let editingId = null;

function loadTasks() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}
function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}
function localDateString(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
function dateLabel(value) {
  if (!value) return "";
  const [y,m,d] = value.split("-");
  return `${y}/${m}/${d}`;
}
function dayDifference(value) {
  const today = new Date();
  today.setHours(0,0,0,0);
  const due = new Date(`${value}T00:00:00`);
  return Math.round((due - today) / 86400000);
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[ch]));
}
function updateStats() {
  const total = tasks.length;
  const done = tasks.filter(t => t.completed).length;
  const soon = tasks.filter(t => !t.completed && t.due && dayDifference(t.due) <= 3 && dayDifference(t.due) >= 0).length;
  document.getElementById("totalCount").textContent = total;
  document.getElementById("doneCount").textContent = done;
  document.getElementById("soonCount").textContent = soon;
  document.getElementById("listCount").textContent = `${visibleTasks().length} 件`;
}
function visibleTasks() {
  let result = tasks.filter(t => activeFilter === "すべて" || t.category === activeFilter);
  if (sortSelect.value === "date") result.sort((a,b) => a.due.localeCompare(b.due));
  if (sortSelect.value === "new") result.sort((a,b) => b.createdAt - a.createdAt);
  if (sortSelect.value === "old") result.sort((a,b) => a.createdAt - b.createdAt);
  return result;
}
function render() {
  const items = visibleTasks();
  taskList.innerHTML = "";
  emptyState.classList.toggle("hidden", items.length !== 0);
  taskList.classList.toggle("hidden", items.length === 0);
  items.forEach(task => {
    const diff = dayDifference(task.due);
    let dueClass = "due";
    let dueText = `期限：${dateLabel(task.due)}`;
    if (!task.completed && diff < 0) { dueClass += " overdue"; dueText += " · 期限切れ"; }
    else if (!task.completed && diff <= 3) { dueClass += " warning"; dueText += diff === 0 ? " · 今日まで" : ` · あと${diff}日`; }
    const tagClass = task.category === "暮らす" ? "life" : task.category === "働く" ? "work" : "";
    const article = document.createElement("article");
    article.className = `task-item ${task.completed ? "completed" : ""}`;
    article.innerHTML = `
      <input class="check" type="checkbox" aria-label="完了にする" ${task.completed ? "checked" : ""}>
      <div class="task-main">
        <p class="task-title">${escapeHTML(task.title)}</p>
        <div class="task-meta"><span class="tag ${tagClass}">${escapeHTML(task.category)}</span><span class="${dueClass}">${dueText}</span></div>
        ${task.memo ? `<p class="memo">${escapeHTML(task.memo)}</p>` : ""}
      </div>
      <div class="task-actions">
        <button class="icon-btn edit" type="button" aria-label="編集" title="編集">✎</button>
        <button class="icon-btn delete" type="button" aria-label="削除" title="削除">×</button>
      </div>`;
    article.querySelector(".check").addEventListener("change", () => {
      task.completed = !task.completed;
      saveTasks(); render();
    });
    article.querySelector(".edit").addEventListener("click", () => startEdit(task.id));
    article.querySelector(".delete").addEventListener("click", () => {
      if (confirm(`「${task.title}」を削除しますか？`)) {
        tasks = tasks.filter(t => t.id !== task.id);
        if (editingId === task.id) resetForm();
        saveTasks(); render();
      }
    });
    taskList.appendChild(article);
  });
  updateStats();
}
function resetForm() {
  form.reset();
  editingId = null;
  document.getElementById("formHeading").textContent = "タスクを追加";
  submitBtn.textContent = "タスクを登録";
  cancelEdit.classList.add("hidden");
}
function startEdit(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  editingId = id;
  titleInput.value = task.title;
  categoryInput.value = task.category;
  dueInput.value = task.due;
  memoInput.value = task.memo || "";
  document.getElementById("formHeading").textContent = "タスクを編集";
  submitBtn.textContent = "変更を保存";
  cancelEdit.classList.remove("hidden");
  titleInput.focus();
  document.querySelector(".form-panel").scrollIntoView({behavior:"smooth",block:"start"});
}
form.addEventListener("submit", event => {
  event.preventDefault();
  const title = titleInput.value.trim();
  const due = dueInput.value;
  if (!title || !due) return;
  if (editingId) {
    const task = tasks.find(t => t.id === editingId);
    if (task) Object.assign(task, {title, category:categoryInput.value, due, memo:memoInput.value.trim()});
  } else {
    tasks.push({
      id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
      title, category:categoryInput.value, due, memo:memoInput.value.trim(),
      completed:false, createdAt:Date.now()
    });
  }
  saveTasks(); resetForm(); render();
});
cancelEdit.addEventListener("click", resetForm);
filterButtons.forEach(button => button.addEventListener("click", () => {
  activeFilter = button.dataset.filter;
  filterButtons.forEach(b => b.classList.toggle("active", b === button));
  render();
}));
sortSelect.addEventListener("change", render);
document.getElementById("todayLabel").textContent = new Intl.DateTimeFormat("ja-JP", {
  year:"numeric", month:"long", day:"numeric", weekday:"short"
}).format(new Date());
dueInput.min = localDateString();
render();
